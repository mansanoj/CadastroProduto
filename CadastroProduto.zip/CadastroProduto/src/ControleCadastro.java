import java.util.ArrayList;

public class ControleCadastro {
	
	private ViewCadastro viewCadastro;
	ArrayList<Produto> listaProdutos = new ArrayList<>();
	
	public ControleCadastro() {
		
		viewCadastro = new ViewCadastro();
		
		controlaMenu();
	}
	
	private void controlaMenu() {
		
		boolean continuar = true;
		
		do {
			String opc = viewCadastro.exibeMenu();

			switch (opc) {
			case "1":
				viewCadastro.inserir(listaProdutos);
				break;
			case "2":
				viewCadastro.listar(listaProdutos);
				break;
			case "3":
				viewCadastro.alterar(listaProdutos);
				break;
			case "4":
				viewCadastro.excluir(listaProdutos);
				break;
			case "5":
				viewCadastro.pesquisar(listaProdutos);
				break;
			case "6":
				viewCadastro.sair();
				continuar = false;
				System.exit(0);
				break;
			default:
				viewCadastro.opc();
				break;
			}
		} while (continuar);
	}

}
