import java.util.ArrayList;
import java.util.Scanner;


public class ViewCadastro {
	
	private Scanner ler;
	
	public ViewCadastro() {
		
		ler = new Scanner(System.in);
	}
	
	public String exibeMenu() {
		
		System.out.println("--- CADASTRO DE PRODUTO ---");
		System.out.println("1 - Inserir");
		System.out.println("2 - Listar");
		System.out.println("3 - Alterar");
		System.out.println("4 - Excluir");
		System.out.println("5 - Pesquisar");
		System.out.println("6 - Sair");
		System.out.println("Op��o: ");
		
		return ler.nextLine();
	}
	
	public Produto inserir(ArrayList<Produto>listaProdutos) {
		
		Produto produtos = new Produto();
		
		System.out.println("Codigo: ");
		produtos.setCodigo(ler.nextLine());
		
		System.out.println("Nome: ");
		produtos.setNome(ler.nextLine());
		
		System.out.println("Quantidade: ");
		produtos.setQuantidade(ler.nextLine());
		
		System.out.println("Pre�o: ");
		produtos.setPreco(ler.nextLine());
		
		listaProdutos.add(produtos);
		
		return produtos;
	}
	
	public void listar(ArrayList<Produto>listaProdutos) {
		
		for(int x = 0; x < listaProdutos.size(); x++) {
			
			System.out.println("Posi��o " + x + listaProdutos.get(x).toString());
			
		}
		

	}
	public void alterar(ArrayList<Produto> listaProdutos) {
		listar(listaProdutos);
		boolean continuar = true;
		int x = 0;
		do {
			System.out.println("Digite a posi��o do registro para alterar: ");
			try {
				x = Integer.parseInt(ler.nextLine());
				if (x >= 0 & x < listaProdutos.size()) {
					continuar = false;
				}else {
					System.out.println("Digite um valor v�lido!");
				}
			} catch (Exception e) {
				System.out.println("Valor digitado inv�lido!!!");
			}
		} while (continuar);
		
		System.out.println("Codigo ("+ listaProdutos.get(x).getCodigo() +"): ");
		listaProdutos.get(x).setCodigo(ler.nextLine());
		
		System.out.println("Nome ("+ listaProdutos.get(x).getNome() +"): ");
		listaProdutos.get(x).setNome(ler.nextLine());
		
		System.out.println("Quantidade ("+ listaProdutos.get(x).getQuantidade() +"): ");
		listaProdutos.get(x).setQuantidade(ler.nextLine());
		
		System.out.println("Pre�o (" + listaProdutos.get(x).getPreco() + "): ");
		listaProdutos.get(x).setPreco(ler.nextLine());
	
	}
	
	public void excluir(ArrayList<Produto>listaProdutos) {
		listar(listaProdutos);
		System.out.println("Digite a posi��o do registro para excluir: ");
		int x = 0;
		x = Integer.parseInt(ler.nextLine());
		listaProdutos.remove(x);
		System.out.println("Registro exlcuido!");
	}
	
	public void pesquisar(ArrayList<Produto>listaProdutos) {
		
		boolean controlePesquisa = true;
		Produto produtos = new Produto();
		System.out.println("Digite o nome do produto para pesquisar: ");
		produtos.setNome(ler.nextLine());
		
		for(int x = 0 ; x < listaProdutos.size(); x++) {
			
			if(listaProdutos.get(x).getNome().equals(produtos.getNome()) == true)
			{
				System.out.println("Produto encontrado!");
				System.out.println("Posi��o " + x + listaProdutos.get(x).toString());
				
				controlePesquisa = false;
				
			}
		}
		
		if(controlePesquisa == true)
		{
			System.out.println("Produto n�o encontrado!");

		}
	}
	public void sair() {
		
		System.out.println("Aplica��o encerrada!");
	}
	
	public void opc() {
		
		System.out.println("Op��o inv�lida");
	}
}
